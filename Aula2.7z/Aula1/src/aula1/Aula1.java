package aula1;

//import javax.swing.JOptionPane;
import javax.swing.Icon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Aula1 {

    public static void main(String[] args) {
        //JOptionPane.showMessageDialog(null,"Olá Mundo");
        JFrame janela = new JFrame("Projeto Diciplina!");
        JPanel painel = new JPanel();
        janela.setSize(300, 200);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setVisible(true);
        janela.add(painel);
        JLabel rotulo = new JLabel();
        String number=JOptionPane.showInputDialog("Digite um número:");
        JOptionPane.showMessageDialog(null, "O número digitado foi: "+ number, "IFRO", JOptionPane.INFORMATION_MESSAGE);
        //Icon icone = new ImageIcon(getResourse("/Imagens/icone.png"));
        painel.add(rotulo);

    }

}
